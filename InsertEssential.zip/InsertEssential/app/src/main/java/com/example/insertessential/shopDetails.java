package com.example.insertessential;

public class shopDetails {
    public String shopName;
    public String shopContact;
    public String shopAddress;
    public String shopImage;

    public shopDetails(String shopName , String shopContact , String shopAddress , String shopImage)
    {
        this.shopName = shopName;
        this.shopAddress = shopAddress;
        this.shopContact = shopContact;
        this.shopImage = shopImage;
    }

    public shopDetails()
    {

    }
}
